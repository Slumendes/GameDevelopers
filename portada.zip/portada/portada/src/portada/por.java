package portada;
     import AppPackage.AnimationClass;  


public class por extends javax.swing.JFrame {
    
   
    private AnimationClass ac = new AnimationClass ();
    
    public por() {
        initComponents();
    this.setLocationRelativeTo(null);

    
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jblSalir = new javax.swing.JButton();
        Pane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 153, 153));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setUndecorated(true);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
        });
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                formMouseReleased(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/portada/line.png"))); // NOI18N
        jLabel1.setText("     Huxilabs");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 40, 250, 50));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/portada/HuxiLab.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 80, 230, 240));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 0));
        jLabel4.setText("Huxilabs");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 20, -1, 40));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 204, 204));
        jLabel9.setText("Bienvenido");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, -1, -1));

        jButton2.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 51, 51));
        jButton2.setText("Iniciar");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255)));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 390, 130, 50));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/portada/LogoSample_ByTailorBrands (7).png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 440, 60, 50));

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/portada/house (2).png"))); // NOI18N
        jLabel6.setToolTipText("");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel6.setName(""); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 30, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/portada/menu (1).png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 30, 30));

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/portada/thought.png"))); // NOI18N
        jLabel8.setToolTipText("");
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel8.setName(""); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 30, 40));

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/portada/pie-chart.png"))); // NOI18N
        jLabel11.setToolTipText("");
        jLabel11.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel11.setName(""); // NOI18N
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 30, 50));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/portada/user (1).png"))); // NOI18N
        jLabel13.setToolTipText("");
        jLabel13.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel13.setName(""); // NOI18N
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 30, 40));

        jLabel14.setBackground(new java.awt.Color(111, 147, 2));
        jLabel14.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(107, 156, 191));
        jLabel14.setText("Home");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(-60, 100, 60, -1));

        jLabel15.setBackground(new java.awt.Color(111, 147, 2));
        jLabel15.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(107, 156, 191));
        jLabel15.setText("Quienes Somos?");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(-150, 250, 140, -1));

        jLabel16.setBackground(new java.awt.Color(111, 147, 2));
        jLabel16.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(107, 156, 191));
        jLabel16.setText("Vision");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(-60, 200, 60, -1));

        jLabel17.setBackground(new java.awt.Color(111, 147, 2));
        jLabel17.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(107, 156, 191));
        jLabel17.setText("Mision");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(-60, 150, 60, -1));

        jblSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/portada/icons8_Sign_Out_32px_1.png"))); // NOI18N
        jblSalir.setBorderPainted(false);
        jblSalir.setContentAreaFilled(false);
        jblSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jblSalirMouseClicked(evt);
            }
        });
        getContentPane().add(jblSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 40, -1));

        Pane1.setPreferredSize(new java.awt.Dimension(60, 96));

        jTextArea1.setBackground(new java.awt.Color(51, 51, 51));
        jTextArea1.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea1.setRows(5);
        jTextArea1.setBorder(null);
        Pane1.setViewportView(jTextArea1);

        getContentPane().add(Pane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-150, 0, 200, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents
 int xy, xx;
    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentResized

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
ac.jTextAreaXRight(-150, 0, 10, 5, Pane1); 
ac.jTextAreaXLeft(0, -150, 10, 5, Pane1);

ac.jLabelXRight(10, 150, 10, 5, jLabel2);//icono
ac.jLabelXLeft(150, 10, 10, 5, jLabel2);

ac.jLabelXRight(-60, 80, 10, 5, jLabel14);//nombres
ac.jLabelXLeft(80, -60, 10, 5, jLabel14);

ac.jLabelXRight(10, 150, 10, 5, jLabel6);
ac.jLabelXLeft(150, 10, 10, 5, jLabel6);

ac.jLabelXRight(-60, 80, 10, 5, jLabel17);
ac.jLabelXLeft(80, -60, 10, 5, jLabel17);

ac.jLabelXRight(10, 150, 10, 5, jLabel11);
ac.jLabelXLeft(150, 10, 10, 5, jLabel11);

ac.jLabelXRight(-60, 80, 10, 5, jLabel16);
ac.jLabelXLeft(80, -60, 10, 5, jLabel16);

ac.jLabelXRight(10, 150, 10, 5, jLabel8);
ac.jLabelXLeft(150, 10, 10, 5, jLabel8);

ac.jLabelXRight(-150, 10, 10, 5, jLabel15);
ac.jLabelXLeft(10, -150, 10, 5, jLabel15);

ac.jLabelXRight(10, 150, 10, 5, jLabel13);
ac.jLabelXLeft(150, 10, 10, 5, jLabel13);

ac.jButtonXRight(10, 150, 10, 5, jblSalir);
ac.jButtonXLeft(150, 10, 10, 5, jblSalir);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jblSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jblSalirMouseClicked
       System.exit(0);
    }//GEN-LAST:event_jblSalirMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked

        
         registro a=new registro();
            a.setVisible(true);
            dispose();

        
    }//GEN-LAST:event_jButton2MouseClicked

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
     setOpacity((float)0.50);
        xx = evt.getX();
        xy = evt.getY();
    }//GEN-LAST:event_formMousePressed

    private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xx, y - xy);
    }//GEN-LAST:event_formMouseDragged

    private void formMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseReleased
       setOpacity((float)1.0);
    }//GEN-LAST:event_formMouseReleased

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new por().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane Pane1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton jblSalir;
    // End of variables declaration//GEN-END:variables
}
